//默认设置项的值
var default_setting_json = {
	right_menu:1,
	hot_key_l:1,
	hot_key_jk:1,
	search_autocomplete:1,
	lib_search:1,
	song_list_show_logo:1,
	multi_send_to_app:1
};